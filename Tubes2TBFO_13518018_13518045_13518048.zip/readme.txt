Python Compiler - Tugas Besar TBFO 2

Steve Bezalel Iman G.	13518018
Anna Elvira Hartoyo	13518045
Hengky Surya Angkasa	13518048

cara penggunaan:
python main.py <nama file>